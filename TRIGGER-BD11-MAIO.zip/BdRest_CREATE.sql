-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema bdrest
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema bdrest
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `bdrest` DEFAULT CHARACTER SET utf8 ;
USE `bdrest` ;

-- -----------------------------------------------------
-- Table `bdrest`.`categoria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bdrest`.`categoria` (
  `idcategoria` INT(11) NOT NULL,
  `nomecategoria` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idcategoria`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bdrest`.`produto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bdrest`.`produto` (
  `idproduto` INT(11) NOT NULL,
  `nomeproduto` VARCHAR(45) NULL DEFAULT NULL,
  `categoria_idcategoria` INT(11) NOT NULL,
  PRIMARY KEY (`idproduto`),
  INDEX `fk_produto_categoria_idx` (`categoria_idcategoria` ASC) VISIBLE,
  CONSTRAINT `fk_produto_categoria`
    FOREIGN KEY (`categoria_idcategoria`)
    REFERENCES `bdrest`.`categoria` (`idcategoria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bdrest`.`pedido`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bdrest`.`pedido` (
  `idpedido` INT(11) NOT NULL,
  `mesa` INT(11) NOT NULL,
  `produto_idproduto` INT(11) NOT NULL,
  `quantidade` INT(11) NULL DEFAULT NULL,
  `textoadicional` TEXT NULL DEFAULT NULL,
  `status` INT(11) NULL DEFAULT '0',
  PRIMARY KEY (`idpedido`, `mesa`, `produto_idproduto`),
  INDEX `fk_pedido_produto1_idx` (`produto_idproduto` ASC) VISIBLE,
  CONSTRAINT `fk_pedido_produto1`
    FOREIGN KEY (`produto_idproduto`)
    REFERENCES `bdrest`.`produto` (`idproduto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
