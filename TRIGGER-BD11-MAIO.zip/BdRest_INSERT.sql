insert into categoria values(1,'Lanche');
insert into categoria values(2,'Bebida');
insert into categoria values(3,'Sobremesa');
insert into categoria values(4,'Porção');
insert into categoria values(5,'Prato');

insert into produto values(100,'X Salada',1);
insert into produto values(101,'X Bacon',1);
insert into produto values(102,'Misto Quente',1);
insert into produto values(103,'Coca cola',2);
insert into produto values(104,'Agua',2);
insert into produto values(105,'Batata Frita',4);
insert into produto values(106,'Pastel',4);
insert into produto values(107,'Do Chefe',5);
insert into produto values(108,'Mexidão',5);
insert into produto values(109,'Sorvete',3);
insert into produto values(110,'Pudim',3);

insert into pedido (idpedido, mesa, produto_idproduto, quantidade) values(1,15,100,2);
insert into pedido (idpedido, mesa, produto_idproduto, quantidade) values(1,15,104,1);
insert into pedido (idpedido, mesa, produto_idproduto, quantidade) values(1,10,109,1);
insert into pedido (idpedido, mesa, produto_idproduto, quantidade) values(1,10,105,2);
insert into pedido (idpedido, mesa, produto_idproduto, quantidade) values(1,11,104,2);
insert into pedido (idpedido, mesa, produto_idproduto, quantidade) values(1,11,101,3);
insert into pedido (idpedido, mesa, produto_idproduto, quantidade) values(1,11,105,3);
